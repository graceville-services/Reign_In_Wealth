#!/usr/bin/env python3
"""Apply the DOMINION Stripe Checkout promo update using Python's standard library.

All files are checked before any source is changed. Existing files are backed
up, individual writes use atomic replacement, and failed installs are reverted.
"""

from __future__ import annotations

import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import uuid


PACKAGE_DIR = Path(__file__).resolve().parent
BACKUP_DIRECTORY = ".dominion-promo-backups"
LOCK_FILENAME = ".dominion-promo-install.lock"
PROTECTED_PARTS = {
    ".git", "node_modules", ".nuxt", ".output", "dist", ".cache",
    BACKUP_DIRECTORY, LOCK_FILENAME,
}
HASH_RE = re.compile(r"^[0-9a-f]{64}$")
WINDOWS_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *{f"COM{i}" for i in range(1, 10)},
    *{f"LPT{i}" for i in range(1, 10)},
}


class InstallError(Exception):
    """A safe, actionable refusal or failure."""


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> dict:
    if path.is_symlink() or not path.is_file():
        raise InstallError(f"Missing or unsafe JSON file: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise InstallError(f"Cannot read {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise InstallError(f"Expected a JSON object in {path}")
    return value


def safe_relative(value: object) -> str:
    if not isinstance(value, str) or not value or "\\" in value or ":" in value:
        raise InstallError(f"Unsafe file path in manifest: {value!r}")
    relative = PurePosixPath(value)
    if relative.is_absolute() or ".." in relative.parts or str(relative) != value:
        raise InstallError(f"Unsafe file path in manifest: {value!r}")
    if value == "." or any("\x00" in part for part in relative.parts):
        raise InstallError(f"Unsafe file path in manifest: {value!r}")
    for part in relative.parts:
        if (part.endswith((".", " "))
                or any(ord(char) < 32 or char in '<>"|?*' for char in part)
                or part.split(".")[0].upper() in WINDOWS_RESERVED_NAMES):
            raise InstallError(f"File path is not portable across supported systems: {value!r}")
        if part.lower() in PROTECTED_PARTS:
            raise InstallError(f"Protected path cannot be replaced: {value}")
        if part.lower().startswith(".env") and part != ".env.example":
            raise InstallError(f"Environment secrets cannot be replaced: {value}")
    return value


def guarded_path(root: Path, relative: str) -> Path:
    """Reject symlinks and non-directory ancestors before accessing a path."""
    current = root
    if current.is_symlink() or not current.is_dir():
        raise InstallError(f"Unsafe directory: {root}")
    parts = PurePosixPath(relative).parts
    for index, part in enumerate(parts):
        current = current / part
        if current.is_symlink():
            raise InstallError(f"Refusing symbolic link: {current}")
        if index < len(parts) - 1 and current.exists() and not current.is_dir():
            raise InstallError(f"A parent path is not a directory: {current}")
    return current


def file_hash(path: Path) -> str | None:
    if path.is_symlink():
        raise InstallError(f"Refusing symbolic link: {path}")
    if not path.exists():
        return None
    if not path.is_file():
        raise InstallError(f"Expected a regular file: {path}")
    return digest(path.read_bytes())


def allowed_original_hashes(entry: dict) -> set[str | None]:
    """Accept explicitly reviewed versions; None means a file may be absent.

    Alternate hashes let the same update support the original repository and
    a known previous installer, including their reviewed line-ending variants.
    The backup always records the exact bytes actually found on the target.
    """
    allowed = {entry["original_sha256"]}
    if "original_sha256_crlf" in entry:
        allowed.add(entry["original_sha256_crlf"])
    allowed.update(entry.get("accepted_original_sha256", []))
    return allowed


def load_manifest() -> dict:
    manifest = read_json(PACKAGE_DIR / "manifest.json")
    if manifest.get("schema_version") != 1:
        raise InstallError("Unsupported manifest schema version.")
    for name in ("package_id", "repository", "base_commit", "app_directory"):
        if not isinstance(manifest.get(name), str) or not manifest[name]:
            raise InstallError(f"Manifest is missing {name}.")
    app_directory = safe_relative(manifest["app_directory"])
    if "/" in app_directory:
        raise InstallError("app_directory must be a single directory name.")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise InstallError("Manifest has no files.")
    seen = set()
    for entry in files:
        if not isinstance(entry, dict):
            raise InstallError("Manifest contains an invalid file entry.")
        relative = safe_relative(entry.get("path"))
        if relative.lower() in seen:
            raise InstallError(f"Duplicate file path: {relative}")
        seen.add(relative.lower())
        for key in ("original_sha256", "updated_sha256"):
            value = entry.get(key)
            if key == "original_sha256" and key in entry and value is None:
                continue
            if not isinstance(value, str) or not HASH_RE.fullmatch(value):
                raise InstallError(f"Invalid {key} for {relative}")
        if "original_sha256_crlf" in entry:
            value = entry["original_sha256_crlf"]
            if (entry["original_sha256"] is None or not isinstance(value, str)
                    or not HASH_RE.fullmatch(value)):
                raise InstallError(f"Invalid original_sha256_crlf for {relative}")
        if "accepted_original_sha256" in entry:
            alternatives = entry["accepted_original_sha256"]
            if (not isinstance(alternatives, list)
                    or any(not isinstance(value, str) or not HASH_RE.fullmatch(value)
                           for value in alternatives)):
                raise InstallError(f"Invalid accepted_original_sha256 for {relative}")
    return manifest


def locate_app(target: str, app_directory: str) -> Path:
    supplied = Path(target).expanduser().absolute()
    if supplied.is_symlink() or not supplied.is_dir():
        raise InstallError(f"Target must be an existing directory, not a symlink: {supplied}")
    supplied = supplied.resolve()
    for candidate in (supplied, supplied / app_directory):
        if candidate.is_symlink():
            raise InstallError(f"Refusing symbolic link: {candidate}")
        if not candidate.is_dir():
            continue
        package_path = guarded_path(candidate, "package.json")
        if not package_path.is_file():
            continue
        package = read_json(package_path)
        if package.get("name") != app_directory:
            continue
        config_path = guarded_path(candidate, "nuxt.config.ts")
        if not config_path.is_file():
            raise InstallError(f"Nuxt configuration is missing: {config_path}")
        return candidate.resolve()
    raise InstallError(
        f"Could not find {app_directory}. Pass --target with the repository "
        "root or the application directory."
    )


def make_plan(manifest: dict, app: Path) -> list[dict]:
    payload = PACKAGE_DIR / "payload"
    if payload.is_symlink() or not payload.is_dir():
        raise InstallError("The installer payload directory is missing or unsafe.")
    plan = []
    errors = []
    for entry in manifest["files"]:
        relative = entry["path"]
        try:
            source = guarded_path(payload, relative)
            if file_hash(source) != entry["updated_sha256"]:
                raise InstallError(f"Payload checksum mismatch: {relative}")
            destination = guarded_path(app, relative)
            current = file_hash(destination)
            if current == entry["updated_sha256"]:
                action = "already installed"
            elif current in allowed_original_hashes(entry):
                action = "create" if current is None else "update"
            else:
                raise InstallError(
                    f"Local file differs from the reviewed versions: {relative}. "
                    "Keep your edits and merge this file manually from payload/."
                )
            plan.append({**entry, "action": action, "current_sha256": current})
        except InstallError as exc:
            errors.append(str(exc))
    if errors:
        raise InstallError("Preflight failed; no source files changed:\n- " + "\n- ".join(errors))
    return plan


def atomic_write(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode & 0o777)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write_json(path: Path, value: dict) -> None:
    atomic_write(path, (json.dumps(value, indent=2) + "\n").encode("utf-8"), 0o600)


@contextlib.contextmanager
def app_lock(app: Path):
    path = app / LOCK_FILENAME
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise InstallError(
            f"An installation lock exists: {path}. If no installer is running, "
            "remove that lock and retry."
        ) from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(f"pid={os.getpid()}\n")
        yield
    finally:
        path.unlink(missing_ok=True)


def print_plan(plan: list[dict]) -> None:
    for entry in plan:
        print(f"  {entry['action']:17} {entry['path']}")


def apply_update(manifest: dict, app: Path) -> None:
    with app_lock(app):
        plan = make_plan(manifest, app)
        changed = [entry for entry in plan if entry["action"] != "already installed"]
        print_plan(plan)
        if not changed:
            print("Already installed. No files changed and no new backup created.")
            return
        backup_root = guarded_path(app, BACKUP_DIRECTORY)
        if backup_root.exists() and not backup_root.is_dir():
            raise InstallError(f"Backup path is not a directory: {backup_root}")
        backup_root.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        backup = backup_root / f"{stamp}-{uuid.uuid4().hex[:8]}"
        backup.mkdir(mode=0o700)
        originals = backup / "originals"
        originals.mkdir(mode=0o700)
        restore = {
            "schema_version": 1,
            "package_id": manifest["package_id"],
            "app_root": str(app),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": "prepared",
            "files": [],
        }
        for entry in changed:
            path = guarded_path(app, entry["path"])
            existed = path.exists()
            mode = stat.S_IMODE(path.stat().st_mode) if existed else 0o644
            if file_hash(path) != entry["current_sha256"]:
                raise InstallError(f"File changed while preparing: {entry['path']}. Retry after reviewing it.")
            if existed:
                atomic_write(guarded_path(originals, entry["path"]), path.read_bytes(), mode)
            restore["files"].append({
                "path": entry["path"],
                "existed": existed,
                "original_sha256": entry["current_sha256"],
                "installed_sha256": entry["updated_sha256"],
                "original_mode": mode & 0o777,
            })
        log = backup / "restore.json"
        write_json(log, restore)
        applied = []
        try:
            for entry in restore["files"]:
                path = guarded_path(app, entry["path"])
                if file_hash(path) != entry["original_sha256"]:
                    raise InstallError(f"File changed during installation: {entry['path']}")
                source = guarded_path(PACKAGE_DIR / "payload", entry["path"])
                contents = source.read_bytes()
                if digest(contents) != entry["installed_sha256"]:
                    raise InstallError(f"Payload changed during installation: {entry['path']}")
                atomic_write(path, contents, entry["original_mode"])
                applied.append(entry)
            restore["status"] = "applied"
            write_json(log, restore)
        except BaseException as exc:
            recovery_errors = []
            for entry in reversed(applied):
                try:
                    restore_entry(app, originals, entry)
                except (InstallError, OSError) as recovery_error:
                    recovery_errors.append(str(recovery_error))
            restore["status"] = "recovery_required" if recovery_errors else "failed_reverted"
            write_json(log, restore)
            detail = "\n" + "\n".join(recovery_errors) if recovery_errors else " Earlier writes were reverted."
            raise InstallError(f"Installation failed: {exc}.{detail}\nBackup: {backup}") from exc
        print(f"Installed {len(changed)} file(s). Backup: {backup}")
        print("Review the changes, run the documented tests/build, and redeploy your application.")


def restore_entry(app: Path, originals: Path, entry: dict) -> bool:
    path = guarded_path(app, entry["path"])
    current = file_hash(path)
    if current == entry["original_sha256"]:
        return False
    if current != entry["installed_sha256"]:
        raise InstallError(f"Refusing to overwrite edits made after installation: {entry['path']}")
    if entry["existed"]:
        source = guarded_path(originals, entry["path"])
        data = source.read_bytes()
        if digest(data) != entry["original_sha256"]:
            raise InstallError(f"Backup checksum mismatch: {entry['path']}")
        atomic_write(path, data, entry["original_mode"])
    else:
        path.unlink()
    return True


def rollback(manifest: dict, app: Path, requested: str, check: bool = False) -> None:
    backup_root = guarded_path(app, BACKUP_DIRECTORY)
    backup = Path(requested).expanduser().absolute()
    if backup.parent != backup_root or backup.is_symlink() or not backup.is_dir():
        raise InstallError(f"Use a backup directory directly inside {backup_root}")
    originals = guarded_path(backup, "originals")
    if not originals.is_dir():
        raise InstallError("The backup originals directory is missing.")
    log = guarded_path(backup, "restore.json")
    restore = read_json(log)
    if (restore.get("schema_version") != 1 or restore.get("app_root") != str(app)
            or restore.get("package_id") != manifest["package_id"]):
        raise InstallError("This backup does not belong to this application and installer.")
    entries = restore.get("files")
    if not isinstance(entries, list) or not entries:
        raise InstallError("The rollback record has no files.")
    seen = set()
    declared_files = {entry["path"]: entry for entry in manifest["files"]}
    for entry in entries:
        if not isinstance(entry, dict):
            raise InstallError("Invalid rollback entry.")
        relative = safe_relative(entry.get("path"))
        if relative.lower() in seen:
            raise InstallError(f"Duplicate rollback path: {relative}")
        seen.add(relative.lower())
        if not isinstance(entry.get("existed"), bool):
            raise InstallError(f"Invalid existence record: {relative}")
        original = entry.get("original_sha256")
        if ((entry["existed"] and (not isinstance(original, str) or not HASH_RE.fullmatch(original)))
                or (not entry["existed"] and original is not None)):
            raise InstallError(f"Invalid original checksum: {relative}")
        installed = entry.get("installed_sha256")
        if not isinstance(installed, str) or not HASH_RE.fullmatch(installed):
            raise InstallError(f"Invalid installed checksum: {relative}")
        declared = declared_files.get(relative)
        if (declared is None or original not in allowed_original_hashes(declared)
                or installed != declared["updated_sha256"]):
            raise InstallError(f"Rollback file does not match this update: {relative}")
        mode = entry.get("original_mode")
        if not isinstance(mode, int) or not 0 <= mode <= 0o777:
            raise InstallError(f"Invalid original mode: {relative}")

    def preflight() -> None:
        errors = []
        for entry in entries:
            try:
                relative = entry["path"]
                if entry["existed"] and file_hash(guarded_path(originals, relative)) != entry["original_sha256"]:
                    raise InstallError(f"Backup checksum mismatch: {relative}")
                current = file_hash(guarded_path(app, relative))
                if current not in (entry["original_sha256"], entry["installed_sha256"]):
                    raise InstallError(f"Refusing to overwrite edits made after installation: {relative}")
            except InstallError as exc:
                errors.append(str(exc))
        if errors:
            raise InstallError("Rollback preflight failed; no source files changed:\n- " + "\n- ".join(errors))

    preflight()
    if check:
        print(f"Rollback check passed for {len(entries)} file(s). No files changed.")
        return
    with app_lock(app):
        preflight()
        count = 0
        for entry in reversed(entries):
            count += int(restore_entry(app, originals, entry))
        restore["status"] = "rolled_back"
        restore["rolled_back_at"] = datetime.now(timezone.utc).isoformat()
        write_json(log, restore)
        print(f"Rollback complete. Restored or removed {count} file(s). Backup retained: {backup}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", default=".", help="Repository root or application directory (default: current directory)")
    parser.add_argument("--check", action="store_true", help="Validate and print the plan without changing files")
    parser.add_argument("--rollback", metavar="BACKUP_DIRECTORY", help="Restore files from a backup created by this installer")
    args = parser.parse_args()
    try:
        manifest = load_manifest()
        app = locate_app(args.target, manifest["app_directory"])
        print(f"Application: {app}")
        if args.rollback:
            rollback(manifest, app, args.rollback, args.check)
        elif args.check:
            plan = make_plan(manifest, app)
            print_plan(plan)
            print("Preflight passed. No files changed.")
        else:
            apply_update(manifest, app)
        return 0
    except (InstallError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Interrupted. Review the latest backup before retrying.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
