"""Offline integration checks for installer safety and recovery."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


SOURCE = Path(__file__).resolve().parents[1] / "install.py"
APP_NAME = "reign-in-wealth-dominion-2026"


def sha(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.distribution = self.root / "installer"
        self.distribution.mkdir()
        shutil.copyfile(SOURCE, self.distribution / "install.py")
        self.repo = self.root / "repo"
        self.app = self.repo / APP_NAME
        self.app.mkdir(parents=True)
        (self.app / "package.json").write_text(json.dumps({"name": APP_NAME}))
        (self.app / "nuxt.config.ts").write_text("export default {}\n")
        (self.app / ".env").write_text("PRESERVE_THIS_SECRET=yes\n")
        self.existing = "app/data/site.ts"
        self.new = "server/api/checkout/quote.post.ts"
        self.original = "export const price = 297\n"
        self.updated = "export const price = 397\n"
        self.new_text = "export const discount = 100\n"
        self.write(self.app / self.existing, self.original)
        self.write(self.distribution / "payload" / self.existing, self.updated)
        self.write(self.distribution / "payload" / self.new, self.new_text)
        self.manifest = {
            "schema_version": 1,
            "package_id": "dominion-stripe-native-2026-v2",
            "repository": "graceville-services/Reign_In_Wealth",
            "base_commit": "70ca22cf7745a3be669d1d3c4cfbe1006db61a9e",
            "app_directory": APP_NAME,
            "files": [
                {"path": self.existing, "original_sha256": sha(self.original), "updated_sha256": sha(self.updated)},
                {"path": self.new, "original_sha256": None, "updated_sha256": sha(self.new_text)},
            ],
        }
        self.save_manifest()

    def tearDown(self):
        self.temp.cleanup()

    def write(self, path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)

    def save_manifest(self):
        (self.distribution / "manifest.json").write_text(json.dumps(self.manifest))

    def run_installer(self, *args, target=None, cwd=None):
        command = [sys.executable, str(self.distribution / "install.py")]
        if target is not False:
            command += ["--target", str(target or self.repo)]
        return subprocess.run(command + list(args), text=True, capture_output=True, cwd=cwd)

    def assert_ok(self, result):
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def assert_refused(self, result, message=None):
        self.assertNotEqual(result.returncode, 0)
        if message:
            self.assertIn(message, result.stderr)

    def snapshot(self):
        return {str(path.relative_to(self.app)): path.read_bytes() for path in self.app.rglob("*") if path.is_file()}

    def get_backup(self):
        backups = list((self.app / ".dominion-promo-backups").iterdir())
        self.assertEqual(len(backups), 1)
        return backups[0]

    def test_check_does_not_mutate(self):
        before = self.snapshot()
        self.assert_ok(self.run_installer("--check"))
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.app / ".dominion-promo-backups").exists())

    def test_apply_and_idempotent_rerun_preserve_environment(self):
        self.assert_ok(self.run_installer())
        self.assertEqual((self.app / self.existing).read_text(), self.updated)
        self.assertEqual((self.app / self.new).read_text(), self.new_text)
        self.assertEqual((self.app / ".env").read_text(), "PRESERVE_THIS_SECRET=yes\n")
        self.assertFalse((self.app / ".dominion-promo-install.lock").exists())
        backup = self.get_backup()
        self.assertEqual((backup / "originals" / self.existing).read_text(), self.original)
        before = self.snapshot()
        self.assert_ok(self.run_installer())
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.get_backup(), backup)

    def test_direct_app_directory_and_default_cwd(self):
        self.assert_ok(self.run_installer("--check", target=self.app))
        self.assert_ok(self.run_installer("--check", target=False, cwd=self.repo))

    def test_crlf_baseline_installs_and_rollback_restores_original_bytes(self):
        original_crlf = self.original.replace("\n", "\r\n").encode()
        (self.app / self.existing).write_bytes(original_crlf)
        self.manifest["files"][0]["original_sha256_crlf"] = hashlib.sha256(original_crlf).hexdigest()
        self.save_manifest()
        before = self.snapshot()
        self.assert_ok(self.run_installer("--check"))
        self.assertEqual(self.snapshot(), before)
        self.assert_ok(self.run_installer())
        self.assertEqual((self.app / self.existing).read_bytes(), self.updated.encode())
        backup = self.get_backup()
        self.assertEqual((backup / "originals" / self.existing).read_bytes(), original_crlf)
        record = json.loads((backup / "restore.json").read_text())
        recorded = next(entry for entry in record["files"] if entry["path"] == self.existing)
        self.assertEqual(recorded["original_sha256"], hashlib.sha256(original_crlf).hexdigest())
        self.assert_ok(self.run_installer("--rollback", str(backup)))
        self.assertEqual((self.app / self.existing).read_bytes(), original_crlf)
        self.assertFalse((self.app / self.new).exists())

    def test_modified_crlf_file_is_still_refused(self):
        original_crlf = self.original.replace("\n", "\r\n").encode()
        self.manifest["files"][0]["original_sha256_crlf"] = hashlib.sha256(original_crlf).hexdigest()
        self.save_manifest()
        (self.app / self.existing).write_bytes(original_crlf + b"// Actual user edit\r\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "Local file differs")
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.app / self.new).exists())

    def add_v1_baselines(self, crlf=False):
        """Declare original/absent source and known v1 bytes as accepted."""
        prior_existing = "export const price = 397\n// v1 website promo\n"
        prior_new = "export const quoteVersion = 'v1'\n"
        for entry, value in zip(self.manifest["files"], [prior_existing, prior_new]):
            entry["accepted_original_sha256"] = [sha(value), sha(value.replace("\n", "\r\n"))]
        self.save_manifest()
        if crlf:
            prior_existing = prior_existing.replace("\n", "\r\n")
            prior_new = prior_new.replace("\n", "\r\n")
        return prior_existing.encode(), prior_new.encode()

    def test_original_repository_baseline_accepts_v2_with_alternates_declared(self):
        self.add_v1_baselines()
        self.assert_ok(self.run_installer("--check"))
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        self.assertEqual((self.app / self.existing).read_bytes(), self.updated.encode())
        self.assertEqual((self.app / self.new).read_bytes(), self.new_text.encode())
        self.assert_ok(self.run_installer("--rollback", str(backup)))
        self.assertEqual((self.app / self.existing).read_bytes(), self.original.encode())
        self.assertFalse((self.app / self.new).exists())

    def test_v1_existing_and_v1_added_files_upgrade_and_rollback_exactly(self):
        prior_existing, prior_new = self.add_v1_baselines()
        (self.app / self.existing).write_bytes(prior_existing)
        (self.app / self.new).parent.mkdir(parents=True, exist_ok=True)
        (self.app / self.new).write_bytes(prior_new)
        before = self.snapshot()
        self.assert_ok(self.run_installer("--check"))
        self.assertEqual(self.snapshot(), before)
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        record = json.loads((backup / "restore.json").read_text())
        new_record = next(entry for entry in record["files"] if entry["path"] == self.new)
        self.assertTrue(new_record["existed"])
        self.assertEqual(new_record["original_sha256"], hashlib.sha256(prior_new).hexdigest())
        self.assertEqual((backup / "originals" / self.new).read_bytes(), prior_new)
        self.assert_ok(self.run_installer())
        self.assertEqual(self.get_backup(), backup)
        self.assert_ok(self.run_installer("--rollback", str(backup), "--check"))
        self.assert_ok(self.run_installer("--rollback", str(backup)))
        self.assertEqual((self.app / self.existing).read_bytes(), prior_existing)
        self.assertEqual((self.app / self.new).read_bytes(), prior_new)
        self.assertEqual((self.app / ".env").read_text(), "PRESERVE_THIS_SECRET=yes\n")

    def test_v1_crlf_upgrade_and_rollback_preserve_exact_bytes(self):
        prior_existing, prior_new = self.add_v1_baselines(crlf=True)
        (self.app / self.existing).write_bytes(prior_existing)
        (self.app / self.new).parent.mkdir(parents=True, exist_ok=True)
        (self.app / self.new).write_bytes(prior_new)
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        self.assertEqual((self.app / self.existing).read_bytes(), self.updated.encode())
        self.assertEqual((self.app / self.new).read_bytes(), self.new_text.encode())
        self.assert_ok(self.run_installer("--rollback", str(backup)))
        self.assertEqual((self.app / self.existing).read_bytes(), prior_existing)
        self.assertEqual((self.app / self.new).read_bytes(), prior_new)

    def test_mixed_original_and_v1_files_restore_their_own_versions(self):
        _, prior_new = self.add_v1_baselines()
        (self.app / self.new).parent.mkdir(parents=True, exist_ok=True)
        (self.app / self.new).write_bytes(prior_new)
        self.assert_ok(self.run_installer())
        self.assert_ok(self.run_installer("--rollback", str(self.get_backup())))
        self.assertEqual((self.app / self.existing).read_bytes(), self.original.encode())
        self.assertEqual((self.app / self.new).read_bytes(), prior_new)

    def test_unknown_edits_to_known_v1_files_are_still_refused(self):
        prior_existing, prior_new = self.add_v1_baselines()
        (self.app / self.existing).write_bytes(prior_existing)
        (self.app / self.new).parent.mkdir(parents=True, exist_ok=True)
        (self.app / self.new).write_bytes(prior_new + b"// User changed v1\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "Local file differs")
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.app / ".dominion-promo-backups").exists())

    def test_invalid_alternate_hashes_are_refused(self):
        for value in (None, sha(self.original), [None], [123], ["not-a-hash"], ["a" * 63]):
            with self.subTest(value=value):
                self.manifest["files"][0]["accepted_original_sha256"] = value
                self.save_manifest()
                before = self.snapshot()
                self.assert_refused(self.run_installer(), "Invalid accepted_original_sha256")
                self.assertEqual(self.snapshot(), before)

    def test_old_package_backup_cannot_be_rolled_back_by_v2(self):
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        log = backup / "restore.json"
        record = json.loads(log.read_text())
        record["package_id"] = "dominion-promo-2026-v1"
        log.write_text(json.dumps(record))
        before = self.snapshot()
        self.assert_refused(self.run_installer("--rollback", str(backup)), "does not belong")
        self.assertEqual(self.snapshot(), before)

    def test_changed_existing_file_refused_before_new_file_created(self):
        self.write(self.app / self.existing, "user edits\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "Local file differs")
        self.assertEqual(self.snapshot(), before)
        self.assertFalse((self.app / self.new).exists())
        self.assertFalse((self.app / ".dominion-promo-backups").exists())

    def test_unexpected_existing_new_file_refused_before_other_updates(self):
        self.write(self.app / self.new, "unrelated implementation\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "Local file differs")
        self.assertEqual(self.snapshot(), before)

    def test_rollback_and_repeated_rollback(self):
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        before = self.snapshot()
        self.assert_ok(self.run_installer("--rollback", str(backup), "--check"))
        self.assertEqual(self.snapshot(), before)
        self.assert_ok(self.run_installer("--rollback", str(backup)))
        self.assertEqual((self.app / self.existing).read_text(), self.original)
        self.assertFalse((self.app / self.new).exists())
        self.assert_ok(self.run_installer("--rollback", str(backup)))

    def test_rollback_preserves_edits_made_since_install(self):
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        self.write(self.app / self.existing, self.updated + "// Later user edit\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer("--rollback", str(backup)), "edits made after installation")
        self.assertEqual(self.snapshot(), before)
        self.assertTrue((self.app / self.new).exists())

    def test_payload_checksum_tampering_refused(self):
        self.write(self.distribution / "payload" / self.new, "tampered\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "Payload checksum mismatch")
        self.assertEqual(self.snapshot(), before)

    def test_manifest_path_traversal_and_protected_paths_refused(self):
        for relative in ("../outside", "/tmp/outside", "app/../../outside", "app\\file", ".env", ".env.production", "node_modules/changed", ".git/config", "app/CON.ts", "app/file.", "app/file "):
            with self.subTest(path=relative):
                self.manifest["files"][1]["path"] = relative
                self.save_manifest()
                self.assert_refused(self.run_installer())
                self.assertEqual((self.app / self.existing).read_text(), self.original)

    def test_target_parent_symlink_refused(self):
        outside = self.root / "outside"
        outside.mkdir()
        (self.app / "server").symlink_to(outside, target_is_directory=True)
        before = self.snapshot()
        self.assert_refused(self.run_installer(), "symbolic link")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(list(outside.iterdir()), [])

    def test_existing_destination_symlink_refused(self):
        destination = self.app / self.existing
        destination.unlink()
        outside = self.root / "outside.ts"
        outside.write_text(self.original)
        destination.symlink_to(outside)
        self.assert_refused(self.run_installer(), "symbolic link")
        self.assertEqual(outside.read_text(), self.original)

    def test_payload_symlink_refused(self):
        source = self.distribution / "payload" / self.new
        source.unlink()
        outside = self.root / "outside.ts"
        outside.write_text(self.new_text)
        source.symlink_to(outside)
        self.assert_refused(self.run_installer(), "symbolic link")

    def test_backup_checksum_tampering_refused(self):
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        self.write(backup / "originals" / self.existing, "tampered backup\n")
        before = self.snapshot()
        self.assert_refused(self.run_installer("--rollback", str(backup)), "Backup checksum mismatch")
        self.assertEqual(self.snapshot(), before)

    def test_backup_root_symlink_refused(self):
        outside = self.root / "outside"
        outside.mkdir()
        (self.app / ".dominion-promo-backups").symlink_to(outside, target_is_directory=True)
        self.assert_refused(self.run_installer(), "symbolic link")
        self.assertEqual((self.app / self.existing).read_text(), self.original)
        self.assertEqual(list(outside.iterdir()), [])

    def test_rollback_record_cannot_add_unrelated_files(self):
        self.assert_ok(self.run_installer())
        backup = self.get_backup()
        restore_path = backup / "restore.json"
        record = json.loads(restore_path.read_text())
        record["files"][0]["path"] = "app/unrelated.ts"
        restore_path.write_text(json.dumps(record))
        before = self.snapshot()
        self.assert_refused(self.run_installer("--rollback", str(backup)), "does not match this update")
        self.assertEqual(self.snapshot(), before)

    def test_wrong_app_refused(self):
        (self.app / "package.json").write_text(json.dumps({"name": "another-app"}))
        self.assert_refused(self.run_installer(), "Could not find")

    def test_mid_install_failure_reverts_earlier_writes(self):
        spec = importlib.util.spec_from_file_location("installer_under_test", SOURCE)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.PACKAGE_DIR = self.distribution
        manifest = module.load_manifest()
        actual_atomic_write = module.atomic_write

        def fail_new_file(path, data, mode=0o644):
            if path == self.app / self.new:
                raise OSError("Simulated disk write failure")
            return actual_atomic_write(path, data, mode)

        with patch.object(module, "atomic_write", side_effect=fail_new_file):
            with self.assertRaisesRegex(module.InstallError, "Earlier writes were reverted"):
                module.apply_update(manifest, self.app)
        self.assertEqual((self.app / self.existing).read_text(), self.original)
        self.assertFalse((self.app / self.new).exists())
        self.assertFalse((self.app / ".dominion-promo-install.lock").exists())
        self.assertEqual(json.loads((self.get_backup() / "restore.json").read_text())["status"], "failed_reverted")


if __name__ == "__main__":
    unittest.main(verbosity=2)
