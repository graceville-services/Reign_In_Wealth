#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$SCRIPT_DIR/install.py" "$@"
elif command -v python >/dev/null 2>&1; then
  exec python "$SCRIPT_DIR/install.py" "$@"
else
  printf '%s\n' 'Python 3.9 or newer is required. Install Python, then run this installer again.' >&2
  exit 1
fi
