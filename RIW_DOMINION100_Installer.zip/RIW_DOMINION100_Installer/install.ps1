$ErrorActionPreference = 'Stop'
$installerPath = Join-Path $PSScriptRoot 'install.py'

if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 $installerPath @args
} elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
    & python3 $installerPath @args
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python $installerPath @args
} else {
    Write-Error 'Python 3.9 or newer is required. Install Python, then run this installer again.'
    exit 1
}

exit $LASTEXITCODE
