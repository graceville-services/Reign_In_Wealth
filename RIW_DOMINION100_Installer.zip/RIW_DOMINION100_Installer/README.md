# DOMINION100 — Stripe Checkout promotion installer (v2)

This version moves promo-code entry onto the Stripe-hosted payment page. It can
upgrade the previous DOMINION100 installer or install directly over the reviewed
GitHub version of `graceville-services/Reign_In_Wealth`.

Package: `dominion-stripe-native-2026-v2`.
Repository baseline: `70ca22cf7745a3be669d1d3c4cfbe1006db61a9e`.

## Customer flow

1. Select a ticket on the website.
2. Enter attendee details and choose quantity.
3. Click **Continue to Stripe**.
4. On Stripe's payment page, select **Add promotion code** and enter **DOMINION100**.
5. Review the discounted total on Stripe, then pay.

The website no longer has a promo-code input or Apply/Remove buttons. It shows
the standard price and subtotal. Stripe validates the code and displays the
final discount before collecting payment.

## Prices and discount scope

| Ticket | Standard price | One ticket with DOMINION100 |
| --- | ---: | ---: |
| Regular Admission | $250 USD | $150 USD |
| VIP Admission | $397 USD | $297 USD |
| Fundraising Gala Only | $197 USD | $97 USD |

**A native fixed $100 Stripe coupon applies once per order, not once per ticket.**
Quantity selection remains available (1–20). Two VIP tickets cost $794 before the
code and **$694 after the code**, not $594. The UI explicitly describes the offer
as **$100 off your order**. This is a scope change from the earlier installer,
which multiplied the discount by ticket quantity before redirecting to Stripe.

Regular and VIP still include the Fundraising Gala. Gala-only admission remains
available separately. The existing ticket benefits and Meta Pixel setup remain.

## Install in your Codespace

Requirements: Python 3.9+ for the installer; Node.js 24 recommended (22.6+ for the
native TypeScript scripts). No new npm dependency is required.

Download this updated ZIP again and upload it to your repository root. From
`/workspaces/Reign_In_Wealth`, run:

```bash
unzip -q -o RIW_DOMINION100_Installer.zip -d /tmp/riw-stripe-v2
python3 /tmp/riw-stripe-v2/RIW_DOMINION100_Installer/install.py --target . --check
python3 /tmp/riw-stripe-v2/RIW_DOMINION100_Installer/install.py --target .
cd reign-in-wealth-dominion-2026
npm ci
npm run stripe:promo:setup -- --apply
npm run test:promo
npm run build
```

**The setup command is required once in the Stripe account/mode you use for
checkout.** Merely setting an environment variable does not create a code in
Stripe. The command uses the app's existing `STRIPE_SECRET_KEY`, loading the app's
`.env` when present. Exported environment variables take precedence.

After successful setup and build, restart your development server or redeploy
through your existing hosting process. Reload the website so the old drawer is
not cached in an open browser tab. An old client that still submits a code to
the app receives a clear instruction to refresh and enter it on Stripe.

For development:

```bash
npm run dev
```

For the existing production Node start command, after building:

```bash
npm start
```

The Python installer only changes source files. It does not deploy, push, change
`.env`, access your Stripe account, or send payments. The separate `--apply`
setup command deliberately creates/reuses the Stripe promotion when you run it.

### Windows

Extract the ZIP. In a terminal at the repository root, use the actual path:

```powershell
py -3 C:\path\to\RIW_DOMINION100_Installer\install.py --target . --check
py -3 C:\path\to\RIW_DOMINION100_Installer\install.py --target .
Set-Location reign-in-wealth-dominion-2026
npm ci
npm run stripe:promo:setup -- --apply
npm run test:promo
npm run build
```

An optional `install.ps1` wrapper is included. Running the Python script directly
does not require changing PowerShell execution policy. Unchanged LF and CRLF
versions of reviewed files are supported; rollback preserves original bytes.
The PowerShell wrapper was not executed on Windows in this environment.

## Stripe setup details

Defaults, documented in `.env.example`:

```dotenv
DOMINION_PROMO_CODE=DOMINION100
DOMINION_PROMO_ENABLED=true
```

The setup command validates all three configured Price IDs before any writes:

| Ticket | Existing Stripe Price ID | Expected amount |
| --- | --- | ---: |
| Regular | `price_1UNBYMGclMcVOhpFTngOzz4H` | 25000 USD cents |
| VIP | `price_1UNBYqGclMcVOhpFb48ZcYkR` | 39700 USD cents |
| Gala | `price_1UNBZIGclMcVOhpFSilUtAkJ` | 19700 USD cents |

Prices must be active, one-time, per-unit USD prices in the Stripe account/mode
used by the key. Their products must be active. If the Price IDs belong to a
different account or mode, update `stripePriceId` for the relevant ticket in
`app/data/site.ts` using the correct Stripe objects. The script does not invent
or replace ticket prices.

With `--apply`, the setup:

- Creates/reuses a $100 USD fixed-amount coupon with duration `once`.
- Restricts it to the configured ticket products.
- Creates/reuses the public promotion code `DOMINION100`.
- Uses the installed Stripe SDK 23 / API 2026-09-30.endive schema, including
  `promotion: { type: 'coupon', coupon: coupon.id }`.
- Adds no expiry, redemption cap, first-order restriction, or customer restriction.
- Verifies existing same-code offers instead of overwriting/deactivating them.
- Supports reruns and concurrent setup safely.
- Prints TEST/LIVE mode and object IDs without printing credentials.

A readiness check performs no writes:

```bash
npm run stripe:promo:setup -- --check
```

Exit code 0 means the code exists and matches the offer; exit code 2 means setup
is missing; exit code 1 means a configuration, conflict, or provider error.
Do not announce the code until setup reports that it is ready in the intended
mode. Test and live modes need their own Price, coupon, and promotion objects.

Your existing secret key needs Price/Product read access and Checkout Session
access for checkout. Administrative setup also needs Coupon and Promotion Code
read/write access. A promotion-code lookup during fulfillment is optional;
failure to resolve the label does not prevent registration.

Native Stripe Checkout accepts any eligible active promotion code in the
account, not an application allowlist of only DOMINION100. Product restrictions
and your Stripe account's promotion settings determine which codes are eligible.
No discount is pre-applied and no custom `discounts` is supplied on the session.

### Disabling or changing the offer

`DOMINION_PROMO_ENABLED=false` hides native code entry on newly created Checkout
sessions and hides promotional website copy after restart/redeploy. It does not
revoke previously created Stripe sessions or deactivate the native promotion.
Disable the actual promotion in Stripe if it must stop being redeemable
elsewhere or on already-issued sessions.

Changing `DOMINION_PROMO_CODE` changes the code that the setup command provisions;
it does not deactivate older Stripe codes. Manage old codes in Stripe.

## The reported CHECKOUT_PROVIDER_ERROR / 502

The earlier JSON response was a generic wrapper. It does not prove whether the
failure came from authentication, price lookup, coupon creation, permissions, or
Checkout Session creation. This version removes all coupon lookup/creation from
the customer checkout request; provisioning happens only in the explicit setup
script.

Checkout now performs:

1. Validate ticket, quantity, attendee details, and canonical site URL.
2. Retrieve and validate the configured full-price Stripe Price.
3. Create a session with `allow_promotion_codes: true` when the offer is enabled.
4. Verify the newly created undiscounted session and return its URL.

If Stripe still rejects a request, the response includes safe diagnostics under
`data.provider`:

```json
{
  "code": "CHECKOUT_PROVIDER_ERROR",
  "provider": {
    "phase": "price_lookup",
    "type": "StripeInvalidRequestError",
    "code": "resource_missing",
    "requestId": "req_example"
  }
}
```

The actual values depend on Stripe's response. `phase` identifies `price_lookup`
or `session_create`; the corresponding terminal log starts with
`DOMINION Stripe checkout failed:` and includes the redacted provider message.
Keys, webhook secrets, bearer tokens, and email addresses are redacted. The raw
provider message is not sent to the customer browser.

A configuration mismatch such as an incorrect ticket price uses a separate
503 error code, including `STRIPE_PRICE_MISMATCH`, instead of a generic 502.
Check `NUXT_PUBLIC_SITE_URL` is the intended HTTPS origin in production (HTTP
localhost is allowed in development). Do not use a URL with a path/query.

## Confirmation and historical payments

Stripe receives the full-price line item. The discount is applied later, when the
customer enters the code on Stripe. No pre-checkout discount, promo code, or
expected discounted total is stored as final payment metadata.

The existing signed webhook and paid-session flow continues to retrieve the
session from Stripe. `amount_total`, `amount_subtotal`, and
`total_details.amount_discount` are authoritative. The code label is obtained
from the paid session's actual promotion data. A failed label lookup does not
block registration/email, and the code is not guessed from configuration.
Older v1 sessions can still use their server-written promo metadata fallback.
No database migration is needed, and past paid totals are not recomputed from
today's catalogue.

## Installer behavior and rollback

This installer accepts the reviewed original GitHub source, the previous
installer's files, their declared CRLF forms, or already-installed v2 files.
It checks the entire payload before changing source and refuses unknown local
edits. If a conflict is reported, preserve the edits and merge the affected
replacement from `payload/`; there is no force-overwrite switch.

Backups record each file's actual preinstallation contents and existence:

```text
reign-in-wealth-dominion-2026/.dominion-promo-backups/<printed-backup-id>/
```

Rolling back a v1-to-v2 upgrade restores v1 files, including files originally
introduced by v1. Rolling back a direct original-to-v2 install removes new files
and restores the original bytes. New edits made after installation are protected.

```bash
python3 /path/to/RIW_DOMINION100_Installer/install.py \
  --target /path/to/Reign_In_Wealth \
  --rollback /exact/printed/v2/backup/path --check

python3 /path/to/RIW_DOMINION100_Installer/install.py \
  --target /path/to/Reign_In_Wealth \
  --rollback /exact/printed/v2/backup/path
```

Use this v2 installer with v2 backups. Keep the v1 installer if you need to
restore a backup created by v1. Source rollback does not delete Stripe resources
created by the explicit setup command; deactivate a native promotion in Stripe
if you need to revoke it.

The installer preserves `.env`, dependencies, build outputs, and Git metadata.
Local backup/lock paths are ignored by Git. Review and commit only the application
directory, not the ZIP or extracted installer folder.

The `.env.example` cleanup from v1 remains: only placeholders are included.
Previously exposed credentials should be rotated, and earlier Git history is
not erased by this update.

## Validation

- 25 backend tests passed: 16 checkout/validation/diagnostic/fulfillment tests and
  9 setup/read-only/conflict/rerun/concurrency tests.
- 6 rendered Vue DOM scenarios passed: no website promo input, correct full-price
  subtotals, quantity and tier changes, attendee validation, disabled offers,
  locked controls during submission, and no promo/price submission from the UI.
- 26 installer tests passed, including original/v1/mixed upgrades, CRLF,
  exact-byte rollback, conflicting edits, protected files, and idempotent reruns.
- Backend/setup TypeScript checks passed.
- Production build and built-route checks are recorded in VALIDATION.txt.
- No live Stripe resource, payment, or email was created by the development checks.
- A live browser/Stripe payment was not verified; UI interaction checks used
  an in-memory rendered Vue DOM. Complete a test-mode payment using matching
  Stripe test objects before relying on the deployment for sales.

Run application tests:

```bash
npm run test:promo
```

Run installer tests from the extracted package:

```bash
python3 -m unittest discover -s tests -v
```

`manifest.json` lists every source/configuration file installed. Full replacements
are in `payload/`, and no old credentials are included in the package.

## References

- Reviewed repository: https://github.com/graceville-services/Reign_In_Wealth/commit/70ca22cf7745a3be669d1d3c4cfbe1006db61a9e
- Stripe Checkout Session creation: https://docs.stripe.com/api/checkout/sessions/create
- Coupon creation and fixed-amount subtotal behavior: https://docs.stripe.com/api/coupons/create
- Native promotion-code creation: https://docs.stripe.com/api/promotion_codes/create
