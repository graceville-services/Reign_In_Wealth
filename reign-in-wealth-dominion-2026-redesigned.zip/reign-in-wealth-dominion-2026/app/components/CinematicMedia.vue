<script setup lang="ts">
withDefaults(defineProps<{ video?: string; poster?: string; alt?: string }>(), { alt: 'DOMINION cinematic visual' })
</script>
<template>
  <div class="media-frame h-full min-h-[360px] bg-forest-deep">
    <video v-if="video" class="cinematic-video absolute inset-0" :src="video" :poster="poster" autoplay muted loop playsinline preload="metadata" aria-hidden="true" />
    <img v-else :src="poster" :alt="alt" class="absolute inset-0 h-full w-full object-cover" loading="lazy" />
    <div class="absolute inset-0 z-10 grid place-items-center"><div class="border border-white/30 bg-forest/30 px-5 py-3 font-mono text-[9px] uppercase tracking-[.2em] text-white/75 backdrop-blur-sm">DOMINION · 2026</div></div>
  </div>
</template>
